package com.exemple;

import java.sql.*;

public class App {
	
	private static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	private static final String JDBC_URL = "jdbc:mysql://localhost/jee";
	private static final String JDBC_USER = "root";
	private static final String JDBC_PASS = "root";
	
	public static void main(String[] args) {
		
		Connection conn = null;
		PreparedStatement stmt = null;
		
		try {
			
			// 1
			System.out.println("Connecting ...");
			conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
			
			// 2
			System.out.println("Create statement ...");
			stmt = conn.prepareStatement("insert into user values (?,?,?,?);");
			
			// 3
			System.out.println("Send SQL ...");
			stmt.setInt(1,55);
			stmt.setString(2,"Elise");
			stmt.setString(3,"Ebene");
			stmt.setString(4,"9 rue jean jaures");
			stmt.executeUpdate();
			
			stmt.setInt(1,88);
			stmt.setString(2,"Fanny");
			stmt.setString(3,"Feuille");
			stmt.setString(4,"77 rue jean jaures");
			stmt.executeUpdate();
			
			//ResultSet rs = stmt.executeQuery("select * from user;");
			int rs = stmt.executeUpdate("insert into user values (40,'Denise','datte','4 rue principale');");
			System.out.println("records:" + rs);
			
			// 4 
			/*
			while(rs.next()){
				System.out.print("User #" + rs.getInt("id"));
				System.out.print(" - " + rs.getString("firstname") + " " + rs.getString("lastname"));
				System.out.println(" - " + rs.getString("address"));
			}
			
			// 5
			rs.close();
			*/
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			
			System.out.println("Exiting ...");
			
			try{
				if(stmt!=null)
					stmt.close();
			}
			catch(Exception e){
				e.printStackTrace();
			}
			
			try{
				if(conn!=null)
					conn.close();
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
	}

}
