package org.exemple.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class UserManager {

	private static final UserManager instance = new UserManager();
	public static final UserManager getInstance(){
		return UserManager.instance;
	}
	
	private Map<Integer,User> cache = new HashMap<>();

	private UserManager(){
		
		User u1 = new User();
		u1.setId(10);
		u1.setFirstname("Alice");
		u1.setLastname("Abricot");
		u1.setAddress("1 place principale");
		this.add(u1);
		
		User u2 = new User();
		u2.setId(20);
		u2.setFirstname("Bob");
		u2.setLastname("Banane");
		u2.setAddress("1 place secondaire");
		this.add(u2);
		
		User u3 = new User();
		u3.setId(30);
		u3.setFirstname("Claude");
		u3.setLastname("Citron");
		u3.setAddress("1 place oubliee");
		this.add(u3);
			
	}

	public void add(User u) {
		this.cache.put(u.getId(),u);
	}
	
	public void del(User u) {
		this.cache.remove(u.getId());
	}
	
	public void upd(User u) {
		this.cache.replace(u.getId(),u);
	}	
	
	public User getbyId(int id){
		return this.cache.get(id);
	}
	
	public List<User> getAll(){
		final List<User> result = new ArrayList<>(this.cache.values());
		return result;
	}
}
